
export const login = (req,res)=> {
  res.json({token:"demo-token"});
};
